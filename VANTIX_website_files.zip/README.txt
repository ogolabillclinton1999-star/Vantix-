VANTIX WEBSITE — DEMO STARTER

FILES
- index.html: website pages and content
- style.css: mobile-friendly dark/neon-blue styling
- app.js: navigation and demo interactions

HOW TO PUBLISH WITH GITHUB PAGES
1. Open your public GitHub repository named vantix.
2. Open the existing index.html and edit it, OR upload these three files to the repository root.
3. If GitHub says index.html already exists, choose to replace/edit the existing file. Do not create a second file with that name.
4. Commit the changes to the main branch.
5. In the repository, open Settings > Pages.
6. Under Build and deployment, choose Deploy from a branch, then main and /(root), and save.
7. Wait for GitHub Pages to publish, then open the website link shown in Settings > Pages.

IMPORTANT
This is a front-end demo starter. It does not connect to Deriv, stream live prices, predict outcomes, or place trades. The analysis output is explicitly illustrative. Deriv API/OAuth integration should be added separately with secure handling and tested only after the demo interface is working. Never put API tokens or passwords in public website files.
