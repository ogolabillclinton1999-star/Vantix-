const navButtons = document.querySelectorAll('.nav-item');
const pages = document.querySelectorAll('.page');
const title = document.getElementById('pageTitle');
const sidebar = document.getElementById('sidebar');
function showPage(name, label) {
  pages.forEach(p => p.classList.toggle('active', p.id === `page-${name}`));
  navButtons.forEach(b => b.classList.toggle('active', b.dataset.page === name));
  title.textContent = label || name.replaceAll('-', ' ').replace(/\b\w/g, c => c.toUpperCase());
  sidebar.classList.remove('open');
}
navButtons.forEach(b => b.addEventListener('click', () => showPage(b.dataset.page, b.querySelector('span').textContent)));
document.getElementById('menuBtn').addEventListener('click', () => sidebar.classList.toggle('open'));
let contract = 'ODD/EVEN';
document.querySelectorAll('.contract').forEach(btn => btn.addEventListener('click', () => {
  document.querySelectorAll('.contract').forEach(b => b.classList.remove('active'));
  btn.classList.add('active'); contract = btn.dataset.contract;
}));
let runs = 0;
document.getElementById('analyzeBtn').addEventListener('click', () => {
  runs++; document.getElementById('analysisCount').textContent = runs;
  const market = document.getElementById('marketSelect').value;
  const result = document.getElementById('resultBox');
  result.querySelector('.result-status').textContent = 'SAMPLE ONLY';
  result.querySelector('.result-main strong').textContent = 'DEMO';
  result.querySelector('.result-main span').textContent = `${market} · ${contract}`;
  result.querySelector('p').textContent = 'No prediction has been calculated. Connect a verified market data source and validate any strategy before relying on analysis.';
});
document.getElementById('saveStrategy').addEventListener('click', () => {
  const name = document.getElementById('strategyName').value.trim() || 'Untitled strategy';
  document.getElementById('strategyFeedback').textContent = `“${name}” saved in this page session as a demo setup. It will not place trades.`;
});
document.querySelectorAll('.use-template').forEach(btn => btn.addEventListener('click', () => {
  showPage('bot-builder', 'Bot Builder');
  document.getElementById('strategyName').value = btn.parentElement.querySelector('h3').textContent;
  document.getElementById('strategyFeedback').textContent = 'Template loaded. Review settings before saving.';
}));
function calculateRisk() {
  const balance = Math.max(0, Number(document.getElementById('balance').value) || 0);
  const pct = Math.min(100, Math.max(0, Number(document.getElementById('riskPct').value) || 0));
  document.getElementById('riskAmount').textContent = '$' + (balance * pct / 100).toFixed(2);
}
document.getElementById('balance').addEventListener('input', calculateRisk);
document.getElementById('riskPct').addEventListener('input', calculateRisk);
calculateRisk();
