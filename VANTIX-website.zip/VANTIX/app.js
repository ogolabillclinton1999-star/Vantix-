const $ = (id) => document.getElementById(id);
const state = { running:false, timer:null, ticks:[], prices:[], history:[], market:"Volatility 100 Index", price:10000, total:0 };
const MAX_TICKS = 50;

function parity(n){ return n % 2 === 0 ? "EVEN" : "ODD"; }
function lastDigit(){ return Math.floor(Math.random()*10); }
function sampleTick(){
  const digit = lastDigit();
  state.total++;
  state.ticks.push(digit);
  if(state.ticks.length > MAX_TICKS) state.ticks.shift();
  state.price += (Math.random()-.48)*12;
  state.prices.push(state.price);
  if(state.prices.length > 45) state.prices.shift();
  const odd = state.ticks.filter(x=>x%2).length;
  const even = state.ticks.length-odd;
  const observation = odd > even ? "ODD has appeared more often in this recent sample." : even > odd ? "EVEN has appeared more often in this recent sample." : "ODD and EVEN are level in this recent sample.";
  state.history.unshift({time:new Date().toLocaleTimeString(),market:state.market,digit,parity:parity(digit),sample:state.ticks.length});
  if(state.history.length>100) state.history.pop();
  render();
}
function render(){
  const n=state.ticks.length, odd=state.ticks.filter(x=>x%2).length, even=n-odd;
  const op=n?Math.round(odd/n*100):0, ep=n?100-op:0;
  $("selectedMarketStat").textContent=state.market;
  $("latestDigit").textContent=n?state.ticks[n-1]:"—";
  $("latestParity").textContent=n?parity(state.ticks[n-1])+" last digit":"Waiting for demo tick";
  $("tickCount").textContent=state.total;
  $("currentSignal").textContent=n?(odd===even?"BALANCED":odd>even?"ODD LEAN":"EVEN LEAN"):"—";
  $("signalBig").textContent=n?(odd===even?"BALANCED":odd>even?"ODD LEAN":"EVEN LEAN"):"WAITING";
  $("signalDescription").textContent=n?`${odd} odd and ${even} even results in the last ${n} demo ticks.`:"Start the demo feed to collect sample ticks.";
  $("oddMeter").style.width=op+"%"; $("evenMeter").style.width=ep+"%";
  $("oddPercent").textContent=op+"%"; $("evenPercent").textContent=ep+"%";
  $("oddCount").textContent=odd; $("evenCount").textContent=even;
  $("oddShare").textContent=op+"%"; $("evenShare").textContent=ep+"%";
  $("observation").textContent=n?(odd>even?"ODD has appeared more often in this recent sample.":even>odd?"EVEN has appeared more often in this recent sample.":"ODD and EVEN are level in this recent sample."):"Start the demo feed to generate sample data.";
  $("digitList").innerHTML=state.ticks.slice().reverse().map(d=>`<span class="digit ${d%2?'odd':'even'}">${d}</span>`).join("");
  $("chartPrice").textContent=state.prices.length?state.price.toFixed(2):"—";
  $("historyBody").innerHTML=state.history.length?state.history.slice(0,40).map(h=>`<tr><td>${h.time}</td><td>${h.market}</td><td>${h.digit}</td><td class="parity-${h.parity.toLowerCase()}">${h.parity}</td><td>${h.sample} ticks</td></tr>`).join(""):'<tr><td colspan="5" class="empty">No demo observations yet.</td></tr>';
  drawChart();
}
function drawChart(){
  const canvas=$("priceChart"), rect=canvas.getBoundingClientRect(), dpr=window.devicePixelRatio||1;
  if(!rect.width||!rect.height)return;
  canvas.width=rect.width*dpr; canvas.height=rect.height*dpr;
  const ctx=canvas.getContext("2d"); ctx.scale(dpr,dpr);
  const w=rect.width,h=rect.height,pad=12;
  ctx.clearRect(0,0,w,h);
  ctx.strokeStyle="#1b3048";ctx.lineWidth=1;
  for(let i=0;i<4;i++){const y=pad+i*(h-pad*2)/3;ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(w,y);ctx.stroke();}
  if(state.prices.length<2)return;
  const min=Math.min(...state.prices),max=Math.max(...state.prices),range=max-min||1;
  const pts=state.prices.map((v,i)=>({x:i/(state.prices.length-1)*w,y:h-pad-(v-min)/range*(h-pad*2)}));
  ctx.beginPath();pts.forEach((p,i)=>i?ctx.lineTo(p.x,p.y):ctx.moveTo(p.x,p.y));
  ctx.strokeStyle="#42c7ff";ctx.lineWidth=2.3;ctx.stroke();
  const grad=ctx.createLinearGradient(0,0,0,h);grad.addColorStop(0,"rgba(53,168,255,.22)");grad.addColorStop(1,"rgba(53,168,255,0)");
  ctx.lineTo(w,h);ctx.lineTo(0,h);ctx.closePath();ctx.fillStyle=grad;ctx.fill();
}
function start(){if(state.running)return;state.running=true;$("startBtn").textContent="Pause demo feed";sampleTick();state.timer=setInterval(sampleTick,1200);}
function stop(){state.running=false;clearInterval(state.timer);state.timer=null;$("startBtn").textContent="Start demo feed";}
$("startBtn").addEventListener("click",()=>state.running?stop():start());
$("resetBtn").addEventListener("click",()=>{stop();state.ticks=[];state.prices=[];state.history=[];state.total=0;state.price=10000;render();});
$("clearHistoryBtn").addEventListener("click",()=>{state.history=[];render();});
$("marketSelect").addEventListener("change",e=>{state.market=e.target.value;render();});
document.querySelectorAll(".nav-link").forEach(btn=>btn.addEventListener("click",()=>{
  document.querySelectorAll(".nav-link").forEach(x=>x.classList.remove("active"));btn.classList.add("active");
  document.querySelectorAll(".view").forEach(x=>x.classList.remove("active"));$(btn.dataset.view).classList.add("active");
  $("pageTitle").textContent=btn.textContent.trim();$("sidebar").classList.remove("open");drawChart();
}));
$("menuBtn").addEventListener("click",()=>$("sidebar").classList.toggle("open"));
window.addEventListener("resize",drawChart);
render();
