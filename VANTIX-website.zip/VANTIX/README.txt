VANTIX WEBSITE — QUICK START

CONTENTS
- index.html: website structure
- style.css: mobile-friendly design and styling
- app.js: demo data, analysis, chart, and history

IMPORTANT
This version is a DEMO interface. It generates sample digits and an illustrative price chart inside your browser. It does not connect to Deriv, fetch live market prices, predict future outcomes, or place trades. The ODD/EVEN reading only describes the recent sample and is not a trading signal or guarantee.

PUBLISH WITH GITHUB PAGES (PHONE)
1. Download and extract VANTIX-website.zip on your phone.
2. Open your GitHub repository.
3. Choose Add file, then Upload files.
4. Upload index.html, style.css, and app.js from the extracted VANTIX folder. README.txt is optional.
5. Commit the files to the repository's main branch.
6. In the repository, open Settings > Pages.
7. Under Build and deployment, choose Deploy from a branch.
8. Select branch main and folder /(root), then Save.
9. Wait a few minutes and open the GitHub Pages URL shown there.

Keep the three website files together in the repository root. The names must match exactly, including lowercase letters.
